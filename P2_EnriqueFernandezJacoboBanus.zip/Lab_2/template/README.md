# About the template

This template is a LaTeX × TU Delft - Report/Thesis Template.

*→ Visit https://dzwaneveld.github.io/report/ for the full documentation.*

## License

This [report/thesis template](https://github.com/dzwaneveld/TU-Delft-Unofficial-Report-Template) by Daan Zwaneveld is licensed under [CC BY-NC 4.0](https://creativecommons.org/licenses/by-nc/4.0/). No attribution is required in PDF outputs created using this template.

## Acknowledgments
CVI Lab teachers at ICAI Comillas would like to thank Daan Zwaneveld for the contributions made over the original TU Delft template and for sharing them.
